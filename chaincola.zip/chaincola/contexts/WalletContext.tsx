'use client'

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { useAuth } from '@/components/AuthProvider'
import { db } from '@/lib/firebase'
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore'

interface WalletContextType {
  balance: number
  updateBalance: (amount: number) => Promise<void>
}

const WalletContext = createContext<WalletContextType | undefined>(undefined)

export const useWallet = () => {
  const context = useContext(WalletContext)
  if (!context) {
    throw new Error('useWallet must be used within a WalletProvider')
  }
  return context
}

export const WalletProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [balance, setBalance] = useState(0)
  const { user } = useAuth()

  useEffect(() => {
    const fetchBalance = async () => {
      if (user) {
        const balanceRef = doc(db, 'balances', user.uid)
        const balanceSnap = await getDoc(balanceRef)
        if (balanceSnap.exists()) {
          setBalance(balanceSnap.data().amount)
        } else {
          await setDoc(balanceRef, { amount: 0 })
        }
      }
    }

    fetchBalance()
  }, [user])

  const updateBalance = async (amount: number) => {
    if (user) {
      const newBalance = balance + amount
      const balanceRef = doc(db, 'balances', user.uid)
      await updateDoc(balanceRef, { amount: newBalance })
      setBalance(newBalance)
    }
  }

  return (
    <WalletContext.Provider value={{ balance, updateBalance }}>
      {children}
    </WalletContext.Provider>
  )
}

