import { Wallet, Shield, Zap } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export function Features() {
  return (
    <section className="py-24 px-4" id="features">
      <div className="container mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12">
          Why Choose ChainCola?
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="bg-black/50 border-gray-800">
            <CardHeader>
              <Wallet className="w-12 h-12 text-white mb-4" />
              <CardTitle className="text-white">Secure Storage</CardTitle>
              <CardDescription className="text-gray-400">
                Your assets are protected with military-grade encryption
              </CardDescription>
            </CardHeader>
          </Card>
          <Card className="bg-black/50 border-gray-800">
            <CardHeader>
              <Shield className="w-12 h-12 text-white mb-4" />
              <CardTitle className="text-white">Multi-Chain Support</CardTitle>
              <CardDescription className="text-gray-400">
                Connect and manage assets across multiple blockchains
              </CardDescription>
            </CardHeader>
          </Card>
          <Card className="bg-black/50 border-gray-800">
            <CardHeader>
              <Zap className="w-12 h-12 text-white mb-4" />
              <CardTitle className="text-white">Lightning Fast</CardTitle>
              <CardDescription className="text-gray-400">
                Experience instant transactions and seamless interactions
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    </section>
  )
}

