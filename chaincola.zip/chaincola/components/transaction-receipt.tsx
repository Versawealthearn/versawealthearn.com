import { useState } from 'react'
import { format } from 'date-fns'
import { QRCodeSVG } from 'qrcode.react'
import { ArrowDown, ArrowUp, Download, Printer } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

interface TransactionReceiptProps {
  transaction: {
    id: number
    type: 'receive' | 'send'
    amount: number
    crypto: string
    date: string
    from: string
    to: string
    networkFee: number
    confirmations: number
    status: string
    blockHeight: number
  }
}

export function TransactionReceipt({ transaction }: TransactionReceiptProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const handlePrint = () => {
    window.print()
  }

  const handleDownload = () => {
    const element = document.getElementById('receipt-content')
    if (element) {
      const receiptHtml = element.outerHTML
      const blob = new Blob([receiptHtml], { type: 'text/html' })
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `transaction_receipt_${transaction.id}.html`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
    }
  }

  return (
    <>
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="outline">View Receipt</Button>
        </DialogTrigger>
        <DialogContent className="max-w-3xl bg-white">
          <DialogHeader>
            <DialogTitle>Transaction Receipt</DialogTitle>
            <DialogDescription>Details of your transaction</DialogDescription>
          </DialogHeader>
          <div id="receipt-content" className="bg-white text-black p-6 rounded-lg">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-center">Transaction Receipt</CardTitle>
                <CardDescription className="text-center">
                  {format(new Date(transaction.date), 'MMMM d, yyyy HH:mm:ss')}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Transaction ID:</span>
                  <span>{transaction.id}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Type:</span>
                  <span className={transaction.type === 'receive' ? 'text-green-600' : 'text-red-600'}>
                    {transaction.type === 'receive' ? (
                      <><ArrowDown className="inline mr-1" /> Received</>
                    ) : (
                      <><ArrowUp className="inline mr-1" /> Sent</>
                    )}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Amount:</span>
                  <span>{transaction.amount} {transaction.crypto}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">From:</span>
                  <span className="text-sm break-all">{transaction.from}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">To:</span>
                  <span className="text-sm break-all">{transaction.to}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Network Fee:</span>
                  <span>{transaction.networkFee} {transaction.crypto}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Status:</span>
                  <span>{transaction.status}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Block Height:</span>
                  <span>{transaction.blockHeight}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Confirmations:</span>
                  <span>{transaction.confirmations}</span>
                </div>
              </CardContent>
              <CardFooter className="flex justify-center">
                <QRCodeSVG value={`https://chaincola.com/tx/${transaction.id}`} size={128} />
              </CardFooter>
            </Card>
          </div>
          <div className="flex justify-end space-x-2 mt-4">
            <Button onClick={handlePrint}>
              <Printer className="mr-2 h-4 w-4" /> Print
            </Button>
            <Button onClick={handleDownload}>
              <Download className="mr-2 h-4 w-4" /> Download
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}

