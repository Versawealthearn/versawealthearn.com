import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface ActionButtonProps {
  icon: React.ReactNode
  label: string
  className?: string
  href: string
}

export function ActionButton({ icon, label, className, href }: ActionButtonProps) {
  return (
    <Link href={href} passHref>
      <Button
        variant="outline"
        className={cn(
          "flex flex-col items-center gap-2 h-auto py-4 px-6 bg-neutral-900 hover:bg-neutral-800 border-neutral-800 text-white rounded-2xl",
          className
        )}
      >
        <div className="h-12 w-12 rounded-full bg-neutral-800 flex items-center justify-center">
          {icon}
        </div>
        <span className="text-sm">{label}</span>
      </Button>
    </Link>
  )
}

