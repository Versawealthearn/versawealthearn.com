import { useState } from 'react'
import { Bell, X } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

interface Notification {
  id: number
  type: 'transaction' | 'security' | 'system'
  message: string
  timestamp: string
}

const mockNotifications: Notification[] = [
  { id: 1, type: 'transaction', message: 'Received 0.05 BTC', timestamp: '2023-06-15T10:30:00Z' },
  { id: 2, type: 'security', message: 'New login detected from unknown device', timestamp: '2023-06-14T14:45:00Z' },
  { id: 3, type: 'system', message: 'System maintenance scheduled for tomorrow', timestamp: '2023-06-13T09:15:00Z' },
  { id: 4, type: 'transaction', message: 'Sent 100 USDC', timestamp: '2023-06-12T16:20:00Z' },
  { id: 5, type: 'transaction', message: 'Received 0.5 ETH', timestamp: '2023-06-11T11:05:00Z' },
]

export function NotificationsBar() {
  const [isOpen, setIsOpen] = useState(false)
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications)

  const toggleNotifications = () => setIsOpen(!isOpen)

  const clearNotification = (id: number) => {
    setNotifications(notifications.filter(notification => notification.id !== id))
  }

  const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
      case 'transaction':
        return '💰'
      case 'security':
        return '🔒'
      case 'system':
        return '🔧'
      default:
        return '📌'
    }
  }

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="icon"
        className="relative"
        onClick={toggleNotifications}
        aria-label="Toggle notifications"
      >
        <Bell className="h-6 w-6 text-white" />
        {notifications.length > 0 && (
          <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
            {notifications.length}
          </span>
        )}
      </Button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 bg-neutral-900 border border-neutral-800 rounded-md shadow-lg z-50">
          <div className="p-4 border-b border-neutral-800">
            <h2 className="text-lg font-semibold text-white">Notifications</h2>
          </div>
          <ScrollArea className="h-[300px]">
            {notifications.length === 0 ? (
              <p className="p-4 text-gray-400">No new notifications</p>
            ) : (
              notifications.map((notification) => (
                <div key={notification.id} className="p-4 border-b border-neutral-800 flex items-start">
                  <span className="mr-2 text-2xl">{getNotificationIcon(notification.type)}</span>
                  <div className="flex-grow">
                    <p className="text-sm text-white">{notification.message}</p>
                    <p className="text-xs text-gray-400">{new Date(notification.timestamp).toLocaleString()}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => clearNotification(notification.id)}
                    aria-label="Clear notification"
                  >
                    <X className="h-4 w-4 text-gray-400" />
                  </Button>
                </div>
              ))
            )}
          </ScrollArea>
        </div>
      )}
    </div>
  )
}

