'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { MoreVertical } from 'lucide-react'
import { useWallet } from '@/contexts/WalletContext'

interface CryptoCardProps {
  icon: string
  name: string
  symbol: string
  balance: string
  balanceUSD: string
  rate: string
  disabled?: boolean
}

export function CryptoCard({
  icon,
  name,
  symbol,
  balance,
  balanceUSD,
  rate,
  disabled = false
}: CryptoCardProps) {
  const [showBuyModal, setShowBuyModal] = useState(false)
  const [showSellModal, setShowSellModal] = useState(false)
  const [amount, setAmount] = useState('')
  const { updateBalance } = useWallet()

  const handleTransaction = (type: 'buy' | 'sell') => {
    const numericAmount = parseFloat(amount)
    if (isNaN(numericAmount) || numericAmount <= 0) {
      alert('Please enter a valid amount')
      return
    }

    if (type === 'sell') {
      const maxSellAmount = parseFloat(balance)
      if (numericAmount > maxSellAmount) {
        alert(`You can't sell more than your current balance of ${balance} ${symbol}`)
        return
      }

      const saleValue = numericAmount * parseFloat(rate)
      updateBalance(saleValue)
      alert(`Successfully sold ${numericAmount} ${symbol} for $${saleValue.toFixed(2)}`)
    } else {
      // Implement buy logic here
      alert(`Bought ${numericAmount} ${symbol}`)
    }

    setAmount('')
    if (type === 'buy') setShowBuyModal(false)
    else setShowSellModal(false)
  }

  return (
    <Card className="bg-neutral-900 border-neutral-800">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Image
              src={icon}
              alt={name}
              width={32}
              height={32}
              className="rounded-full"
            />
            <span className="text-lg font-medium text-white">{name}</span>
          </div>
          <div className="text-right">
            <div className="text-lg font-medium text-white">{balanceUSD}</div>
            <div className="text-sm text-gray-400">{balance} {symbol}</div>
          </div>
        </div>
        <div className="text-sm text-gray-400 mb-4">
          1 {symbol} = {rate} USD
        </div>
        <div className="flex items-center gap-3">
          <Dialog open={showSellModal} onOpenChange={setShowSellModal}>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                className="flex-1 bg-neutral-800 hover:bg-neutral-700 text-white border-neutral-700"
                disabled={disabled}
              >
                Sell
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-neutral-900 border-neutral-800 text-white">
              <DialogHeader>
                <DialogTitle>Sell {symbol}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div>
                  <Label htmlFor="sell-amount">Amount to sell</Label>
                  <Input
                    id="sell-amount"
                    type="number"
                    placeholder={`0 ${symbol}`}
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="bg-neutral-800 border-neutral-700 text-white"
                  />
                </div>
                <Button onClick={() => handleTransaction('sell')} className="w-full bg-red-600 hover:bg-red-700">
                  Confirm Sell
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={showBuyModal} onOpenChange={setShowBuyModal}>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                className="flex-1 bg-neutral-800 hover:bg-neutral-700 text-white border-neutral-700"
              >
                Buy
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-neutral-900 border-neutral-800 text-white">
              <DialogHeader>
                <DialogTitle>Buy {symbol}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div>
                  <Label htmlFor="buy-amount">Amount to buy</Label>
                  <Input
                    id="buy-amount"
                    type="number"
                    placeholder={`0 ${symbol}`}
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="bg-neutral-800 border-neutral-700 text-white"
                  />
                </div>
                <Button onClick={() => handleTransaction('buy')} className="w-full bg-green-600 hover:bg-green-700">
                  Confirm Buy
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Button
            variant="ghost"
            size="icon"
            className="text-gray-400 hover:text-white hover:bg-neutral-800"
          >
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

