'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Wallet, BarChart2, LineChart, User } from 'lucide-react'
import { cn } from "@/lib/utils"

const navItems = [
  { icon: Home, label: 'Home', href: '/dashboard' },
  { icon: Wallet, label: 'Wallet', href: '/dashboard/wallet' },
  { icon: BarChart2, label: 'Market', href: '/dashboard/market' },
  { icon: LineChart, label: 'Trades', href: '/dashboard/trades' },
  { icon: User, label: 'Account', href: '/dashboard/account' },
]

export function BottomNav() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-neutral-900 border-t border-neutral-800 px-4 py-2">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          
          return (
            <Link
              key={item.href}
              href={item.href}
              className="flex flex-col items-center gap-1 py-2"
            >
              <Icon
                className={cn(
                  "h-6 w-6",
                  isActive ? "text-white" : "text-gray-400"
                )}
              />
              <span
                className={cn(
                  "text-xs",
                  isActive ? "text-white" : "text-gray-400"
                )}
              >
                {item.label}
              </span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}

