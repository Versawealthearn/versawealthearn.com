'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Menu, X } from 'lucide-react'

export function MobileMenu() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="md:hidden">
      <Button variant="ghost" size="icon" onClick={() => setIsOpen(!isOpen)}>
        {isOpen ? <X className="h-6 w-6 text-white" /> : <Menu className="h-6 w-6 text-white" />}
      </Button>
      {isOpen && (
        <div className="absolute top-16 left-0 right-0 bg-blue-950 p-4 flex flex-col gap-4">
          <Link href="#features" className="text-gray-300 hover:text-white transition-colors">
            Features
          </Link>
          <Link href="#security" className="text-gray-300 hover:text-white transition-colors">
            Security
          </Link>
          <Link href="#about" className="text-gray-300 hover:text-white transition-colors">
            About
          </Link>
          <Link href="/login" passHref>
            <Button variant="ghost" className="text-gray-300 hover:text-white transition-colors justify-start">
              Login
            </Button>
          </Link>
          <Link href="/signup" passHref>
            <Button variant="outline" className="text-white border-white hover:bg-white hover:text-black w-full">
              Sign Up
            </Button>
          </Link>
        </div>
      )}
    </div>
  )
}

