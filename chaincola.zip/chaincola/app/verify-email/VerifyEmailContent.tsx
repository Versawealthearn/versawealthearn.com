'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { auth } from '@/lib/firebase'

export default function VerifyEmailContent() {
  const [status, setStatus] = useState<'verifying' | 'success' | 'error'>('verifying')
  const router = useRouter()

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        if (user.emailVerified) {
          setStatus('success')
        } else {
          setStatus('error')
        }
      } else {
        setStatus('error')
      }
    })

    return () => unsubscribe()
  }, [])

  const handleContinue = () => {
    router.push('/create-pin')
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-950 to-black p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Email Verification</CardTitle>
          <CardDescription>
            {status === 'verifying' && 'We are verifying your email...'}
            {status === 'success' && 'Your email has been successfully verified!'}
            {status === 'error' && 'There was an error verifying your email. Please try again.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {status === 'success' && (
            <div className="space-y-4">
              <p>Your email has been verified successfully. You can now create a PIN to secure your account.</p>
              <Button onClick={handleContinue} className="w-full">
                Continue to Create PIN
              </Button>
            </div>
          )}
          {status === 'error' && (
            <p>If you continue to have issues, please contact our support team.</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

