'use server'

import { cookies } from 'next/headers'
import { auth } from '@/lib/firebase'
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail, sendEmailVerification } from 'firebase/auth'

export async function login(email: string, password: string) {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password)
    const user = userCredential.user
    cookies().set('session', await user.getIdToken(), { httpOnly: true, secure: true })
    return { success: true }
  } catch (error) {
    return { success: false, error: error.message }
  }
}

export async function signup(email: string, password: string) {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password)
    const user = userCredential.user
    await sendEmailVerification(user)
    return { success: true }
  } catch (error) {
    return { success: false, error: error.message }
  }
}

export async function forgotPassword(email: string) {
  try {
    await sendPasswordResetEmail(auth, email)
    return { success: true }
  } catch (error) {
    return { success: false, error: error.message }
  }
}

export async function verifyEmail(token: string) {
  // Firebase handles email verification automatically
  // This function is kept for compatibility, but it's not needed for Firebase
  return { success: true }
}

export async function createPin(pin: string) {
  // In a real application, you would associate this PIN with the user's Firebase UID
  // For this example, we'll just set a cookie
  cookies().set('pin_set', 'true', { httpOnly: true, secure: true })
  return { success: true }
}

