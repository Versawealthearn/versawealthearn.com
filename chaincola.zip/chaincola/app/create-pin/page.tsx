'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { createPin } from '@/app/actions'

export default function CreatePinPage() {
  const [pin, setPin] = useState('')
  const [confirmPin, setConfirmPin] = useState('')
  const [error, setError] = useState('')
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (pin !== confirmPin) {
      setError('PINs do not match')
      return
    }

    if (pin.length !== 6) {
      setError('PIN must be 6 digits')
      return
    }

    try {
      await createPin(pin)
      router.push('/dashboard')
    } catch (err) {
      setError('An error occurred. Please try again.')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-950 to-black p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Create Your PIN</CardTitle>
          <CardDescription>
            Create a 6-digit PIN to secure your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="pin">PIN</Label>
              <Input 
                id="pin" 
                type="password" 
                placeholder="Enter your 6-digit PIN" 
                value={pin} 
                onChange={(e) => setPin(e.target.value)}
                maxLength={6}
                pattern="\d{6}"
                required 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmPin">Confirm PIN</Label>
              <Input 
                id="confirmPin" 
                type="password" 
                placeholder="Confirm your PIN" 
                value={confirmPin} 
                onChange={(e) => setConfirmPin(e.target.value)}
                maxLength={6}
                pattern="\d{6}"
                required 
              />
            </div>
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <Button type="submit" className="w-full">
              Create PIN
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

