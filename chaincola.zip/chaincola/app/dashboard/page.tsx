'use client'

import { useEffect, useState } from 'react'
import { ArrowUpRight, ArrowDownRight, RefreshCw, ArrowDown, ArrowUp } from 'lucide-react'
import { ActionButton } from '@/components/action-button'
import { BottomNav } from '@/components/bottom-nav'
import { CryptoCard } from '@/components/ui/crypto-card'
import { NotificationsBar } from '@/components/notifications-bar'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from 'next/link'
import { useAuth } from '@/components/AuthProvider'
import { db } from '@/lib/firebase'
import { collection, query, where, getDocs } from 'firebase/firestore'

interface Transaction {
  id: number
  type: 'receive' | 'send'
  amount: number
  crypto: string
  date: string
}

export default function DashboardPage() {
  const { user } = useAuth()
  const [balance, setBalance] = useState(0)
  const [transactions, setTransactions] = useState<Transaction[]>([])

  useEffect(() => {
    const fetchData = async () => {
      if (user) {
        // Fetch balance
        const balanceRef = collection(db, 'balances')
        const balanceQuery = query(balanceRef, where('userId', '==', user.uid))
        const balanceSnapshot = await getDocs(balanceQuery)
        if (!balanceSnapshot.empty) {
          setBalance(balanceSnapshot.docs[0].data().amount)
        }

        // Fetch transactions
        const transactionsRef = collection(db, 'transactions')
        const transactionsQuery = query(transactionsRef, where('userId', '==', user.uid))
        const transactionsSnapshot = await getDocs(transactionsQuery)
        const fetchedTransactions = transactionsSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Transaction[]
        setTransactions(fetchedTransactions)
      }
    }

    fetchData()
  }, [user])

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Wallet</h1>
        <NotificationsBar />
      </div>

      {/* Balance */}
      <div className="p-4">
        <div className="text-gray-400 mb-2">TOTAL BALANCE</div>
        <div className="text-4xl font-bold">${balance.toFixed(2)} USD</div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-3 gap-4 px-4 mb-6">
        <ActionButton
          icon={<ArrowUpRight className="h-6 w-6" />}
          label="Send"
          href="/dashboard/send"
        />
        <ActionButton
          icon={<ArrowDownRight className="h-6 w-6" />}
          label="Receive"
          href="/dashboard/receive"
        />
        <ActionButton
          icon={<RefreshCw className="h-6 w-6" />}
          label="Convert"
          href="/dashboard/convert"
        />
      </div>

      {/* Crypto Cards */}
      <div className="space-y-4 px-4 mb-6">
        <CryptoCard
          icon="/placeholder.svg?height=32&width=32"
          name="BITCOIN"
          symbol="BTC"
          balance="0.00000269"
          balanceUSD="0.26"
          rate="97259.81"
        />
        <CryptoCard
          icon="/placeholder.svg?height=32&width=32"
          name="ETHEREUM"
          symbol="ETH"
          balance="0"
          balanceUSD="0"
          rate="4006"
        />
        <CryptoCard
          icon="/placeholder.svg?height=32&width=32"
          name="USDC"
          symbol="USDC"
          balance="0"
          balanceUSD="0"
          rate="1"
        />
      </div>

      {/* Recent Transactions */}
      <Card className="mx-4 bg-neutral-900 border-neutral-800">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Recent Transactions</CardTitle>
          <Link href="/dashboard/trades" className="text-xs text-blue-400 hover:underline">
            View All
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {transactions.map((transaction) => (
              <div key={transaction.id} className="flex items-center">
                <div className={`mr-2 p-2 rounded-full ${
                  transaction.type === 'receive' ? 'bg-green-500/20' : 'bg-red-500/20'
                }`}>
                  {transaction.type === 'receive' ? (
                    <ArrowDown className="h-4 w-4 text-green-500" />
                  ) : (
                    <ArrowUp className="h-4 w-4 text-red-500" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">
                    {transaction.type === 'receive' ? 'Received' : 'Sent'} {transaction.amount} {transaction.crypto}
                  </p>
                  <p className="text-xs text-gray-400">
                    {new Date(transaction.date).toLocaleString()}
                  </p>
                </div>
                <div className={`text-sm font-medium ${
                  transaction.type === 'receive' ? 'text-green-500' : 'text-red-500'
                }`}>
                  {transaction.type === 'receive' ? '+' : '-'}{transaction.amount} {transaction.crypto}
                </div>
                <div className="flex space-x-2">
                  <Link href={`/dashboard/transaction/${transaction.id}`}>
                    <Button variant="outline" size="sm">View</Button>
                  </Link>
                  <Link href={`/dashboard/transaction/${transaction.id}`}>
                    <Button variant="outline" size="sm">Receipt</Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Lightning Network Banner */}
      <div className="mx-4 mt-6 p-4 bg-neutral-900 rounded-lg border border-neutral-800">
        <div className="flex items-center gap-2">
          <span>Use Lightning network ⚡</span>
          <span className="text-xs px-2 py-1 bg-yellow-400/20 text-yellow-400 rounded">New</span>
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

