'use client'

import { useState } from 'react'
import { ArrowLeft, ArrowUpRight, ArrowDownRight } from 'lucide-react'
import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Mock data for trades
const mockTrades = [
  { id: 1, type: 'buy', status: 'active', crypto: 'BTC', amount: 0.5, price: 50000, counterparty: 'Alice', date: '2023-06-15T10:30:00Z' },
  { id: 2, type: 'sell', status: 'active', crypto: 'ETH', amount: 2, price: 3000, counterparty: 'Bob', date: '2023-06-14T14:45:00Z' },
  { id: 3, type: 'buy', status: 'completed', crypto: 'USDC', amount: 1000, price: 1, counterparty: 'Charlie', date: '2023-06-13T09:15:00Z' },
  { id: 4, type: 'sell', status: 'completed', crypto: 'BTC', amount: 0.2, price: 51000, counterparty: 'David', date: '2023-06-12T16:20:00Z' },
]

function TradeCard({ trade }: { trade: typeof mockTrades[0] }) {
  return (
    <Card className="bg-neutral-900 border-neutral-800">
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-2">
          <span className="font-semibold">{trade.crypto}</span>
          <span className={`text-sm ${trade.type === 'buy' ? 'text-green-500' : 'text-red-500'}`}>
            {trade.type === 'buy' ? 'Buy' : 'Sell'}
          </span>
        </div>
        <div className="flex justify-between items-center mb-2">
          <span>Amount: {trade.amount} {trade.crypto}</span>
          <span>Price: ${trade.price.toFixed(2)}</span>
        </div>
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-gray-400">Counterparty: {trade.counterparty}</span>
          <span className="text-sm text-gray-400">{new Date(trade.date).toLocaleString()}</span>
        </div>
        {trade.status === 'active' && (
          <Button className="w-full mt-2 bg-blue-600 hover:bg-blue-700">
            View Details
          </Button>
        )}
      </CardContent>
    </Card>
  )
}

export default function TradesPage() {
  return (
    <div className="min-h-screen bg-black text-white p-4 pb-20">
      <div className="flex items-center mb-6">
        <Link href="/dashboard" className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Link>
        <h1 className="text-2xl font-bold">Trades</h1>
      </div>

      <Tabs defaultValue="active" className="mb-6">
        <TabsList className="bg-neutral-900 border-neutral-800">
          <TabsTrigger value="active" className="data-[state=active]:bg-blue-600">Active Trades</TabsTrigger>
          <TabsTrigger value="completed" className="data-[state=active]:bg-blue-600">Completed Trades</TabsTrigger>
        </TabsList>
        <TabsContent value="active">
          <div className="space-y-4">
            {mockTrades.filter(trade => trade.status === 'active').map(trade => (
              <TradeCard key={trade.id} trade={trade} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="completed">
          <div className="space-y-4">
            {mockTrades.filter(trade => trade.status === 'completed').map(trade => (
              <TradeCard key={trade.id} trade={trade} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

