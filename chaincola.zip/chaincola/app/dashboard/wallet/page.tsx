'use client'

import { useState } from 'react'
import { ArrowLeft, Plus, ArrowUpRight } from 'lucide-react'
import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function WalletPage() {
  const [showDeposit, setShowDeposit] = useState(false)
  const [showTransfer, setShowTransfer] = useState(false)

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="flex items-center mb-6">
        <Link href="/dashboard" className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Link>
        <h1 className="text-2xl font-bold">Wallet</h1>
      </div>

      <Card className="bg-neutral-900 border-neutral-800 mb-6">
        <CardHeader>
          <CardTitle className="text-white">Total Balance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold mb-4">$1,234.56</div>
          <div className="flex space-x-4">
            <Dialog open={showDeposit} onOpenChange={setShowDeposit}>
              <DialogTrigger asChild>
                <Button className="flex-1 bg-blue-600 hover:bg-blue-700">
                  <Plus className="mr-2 h-4 w-4" /> Deposit
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-neutral-900 border-neutral-800 text-white">
                <DialogHeader>
                  <DialogTitle>Deposit Funds</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <Label htmlFor="deposit-amount">Amount</Label>
                    <Input id="deposit-amount" placeholder="0.00" type="number" className="bg-neutral-800 border-neutral-700 text-white" />
                  </div>
                  <div>
                    <Label htmlFor="deposit-currency">Currency</Label>
                    <Select>
                      <SelectTrigger id="deposit-currency" className="bg-neutral-800 border-neutral-700 text-white">
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent className="bg-neutral-800 border-neutral-700 text-white">
                        <SelectItem value="usd">USD</SelectItem>
                        <SelectItem value="btc">Bitcoin</SelectItem>
                        <SelectItem value="eth">Ethereum</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Confirm Deposit</Button>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={showTransfer} onOpenChange={setShowTransfer}>
              <DialogTrigger asChild>
                <Button variant="outline" className="flex-1 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white">
                  <ArrowUpRight className="mr-2 h-4 w-4" /> Transfer
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-neutral-900 border-neutral-800 text-white">
                <DialogHeader>
                  <DialogTitle>Transfer Funds</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <Label htmlFor="transfer-amount">Amount</Label>
                    <Input id="transfer-amount" placeholder="0.00" type="number" className="bg-neutral-800 border-neutral-700 text-white" />
                  </div>
                  <div>
                    <Label htmlFor="transfer-currency">Currency</Label>
                    <Select>
                      <SelectTrigger id="transfer-currency" className="bg-neutral-800 border-neutral-700 text-white">
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent className="bg-neutral-800 border-neutral-700 text-white">
                        <SelectItem value="usd">USD</SelectItem>
                        <SelectItem value="btc">Bitcoin</SelectItem>
                        <SelectItem value="eth">Ethereum</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="transfer-to">Recipient Address</Label>
                    <Input id="transfer-to" placeholder="Enter recipient's address" className="bg-neutral-800 border-neutral-700 text-white" />
                  </div>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Confirm Transfer</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      <h2 className="text-xl font-semibold mb-4">Your Assets</h2>
      <div className="space-y-4">
        {['Bitcoin', 'Ethereum', 'USD Coin'].map((asset) => (
          <Card key={asset} className="bg-neutral-900 border-neutral-800">
            <CardContent className="flex items-center justify-between p-4">
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-blue-600 mr-4"></div>
                <div>
                  <div className="font-semibold">{asset}</div>
                  <div className="text-sm text-gray-400">0.00 {asset === 'USD Coin' ? 'USDC' : asset === 'Bitcoin' ? 'BTC' : 'ETH'}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-semibold">$0.00</div>
                <div className="text-sm text-gray-400">0.00%</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

