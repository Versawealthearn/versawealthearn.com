'use client'

import { useState } from 'react'
import { ArrowLeft, Copy, QrCode } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from 'next/link'
import { QRCodeSVG } from 'qrcode.react'

const coins = [
  { name: 'Bitcoin', symbol: 'BTC', address: '1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2' },
  { name: 'Ethereum', symbol: 'ETH', address: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e' },
  { name: 'USD Coin', symbol: 'USDC', address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48' },
]

export default function ReceivePage() {
  const [selectedCoin, setSelectedCoin] = useState<string | null>(null)
  const [amount, setAmount] = useState('')
  const [showQR, setShowQR] = useState(false)

  const handleCoinSelect = (value: string) => {
    setSelectedCoin(value)
    setShowQR(false)
  }

  const selectedCoinData = coins.find(coin => coin.symbol === selectedCoin)

  const handleCopy = () => {
    if (selectedCoinData) {
      navigator.clipboard.writeText(selectedCoinData.address)
      // You might want to show a toast notification here
    }
  }

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="flex items-center mb-6">
        <Link href="/dashboard" className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Link>
        <h1 className="text-2xl font-bold">Receive</h1>
      </div>

      <div className="space-y-6">
        <div>
          <Label htmlFor="currency">Select Coin</Label>
          <Select onValueChange={handleCoinSelect}>
            <SelectTrigger id="currency" className="w-full mt-2 bg-neutral-900 border-neutral-800 text-white">
              <SelectValue placeholder="Select coin to receive" />
            </SelectTrigger>
            <SelectContent className="bg-neutral-900 border-neutral-800 text-white">
              {coins.map((coin) => (
                <SelectItem key={coin.symbol} value={coin.symbol}>{coin.name} ({coin.symbol})</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedCoin && (
          <>
            <div>
              <Label htmlFor="amount">Amount (Optional)</Label>
              <Input
                id="amount"
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full mt-2 bg-neutral-900 border-neutral-800 text-white"
              />
            </div>

            <div>
              <Label htmlFor="address">Your {selectedCoin} Address</Label>
              <div className="flex mt-2">
                <Input
                  id="address"
                  readOnly
                  value={selectedCoinData?.address}
                  className="flex-grow bg-neutral-900 border-neutral-800 text-white"
                />
                <Button onClick={handleCopy} variant="outline" className="ml-2 bg-neutral-900 border-neutral-800 text-white">
                  <Copy className="h-5 w-5" />
                </Button>
              </div>
            </div>

            <div className="flex justify-center">
              {showQR ? (
                <QRCodeSVG 
                  value={`${selectedCoin}:${selectedCoinData?.address}${amount ? `?amount=${amount}` : ''}`} 
                  size={200}
                  bgColor="#000000"
                  fgColor="#ffffff"
                />
              ) : (
                <Button onClick={() => setShowQR(true)} className="bg-blue-600 hover:bg-blue-700 text-white">
                  <QrCode className="h-5 w-5 mr-2" />
                  Show QR Code
                </Button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  )
}

