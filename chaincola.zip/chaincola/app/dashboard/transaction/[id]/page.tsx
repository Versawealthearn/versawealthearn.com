'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { ArrowLeft, ArrowDown, ArrowUp } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { TransactionReceipt } from '@/components/transaction-receipt'

// Mock transaction data (in a real app, this would come from an API)
const mockTransactions = [
  { 
    id: 1, 
    type: 'receive', 
    amount: 0.05, 
    crypto: 'BTC', 
    date: '2023-06-15T10:30:00Z', 
    from: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa', 
    to: '3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy',
    networkFee: 0.0001,
    confirmations: 6,
    status: 'Confirmed',
    blockHeight: 789101
  },
  { id: 2, type: 'send', amount: 100, crypto: 'USDC', date: '2023-06-14T14:45:00Z', from: '3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy', to: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa', networkFee: 0.001, confirmations: 12, status: 'Confirmed', blockHeight: 789095 },
  { id: 3, type: 'receive', amount: 0.5, crypto: 'ETH', date: '2023-06-13T09:15:00Z', from: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e', to: '0xde0B295669a9FD93d5F28D9Ec85E40f4cb697BAe', networkFee: 0.002, confirmations: 3, status: 'Confirmed', blockHeight: 789088 },
  { id: 4, type: 'send', amount: 0.01, crypto: 'BTC', date: '2023-06-12T16:20:00Z', from: '3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy', to: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa', networkFee: 0.0002, confirmations: 24, status: 'Confirmed', blockHeight: 789076 },
]

export default function TransactionPage() {
  const router = useRouter()
  const { id } = useParams()
  const [transaction, setTransaction] = useState<typeof mockTransactions[0] | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchTransaction = async () => {
      setLoading(true)
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      const foundTransaction = mockTransactions.find(t => t.id === Number(id))
      setTransaction(foundTransaction || null)
      setLoading(false)
    }

    fetchTransaction()
  }, [id])

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white p-4">
        <div className="flex items-center mb-6">
          <Skeleton className="h-6 w-6 mr-4" />
          <Skeleton className="h-8 w-48" />
        </div>
        <Card className="bg-neutral-900 border-neutral-800 mb-6">
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent className="space-y-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="flex justify-between">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-32" />
              </div>
            ))}
          </CardContent>
        </Card>
        <Skeleton className="h-10 w-full" />
      </div>
    )
  }

  if (!transaction) {
    return <div className="min-h-screen bg-black text-white p-4">Transaction not found</div>
  }

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="flex items-center mb-6">
        <Button variant="ghost" onClick={() => router.back()} className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-2xl font-bold">Transaction Details</h1>
      </div>

      <Card className="bg-neutral-900 border-neutral-800 mb-6">
        <CardHeader>
          <CardTitle className="text-white">Transaction Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-gray-400">Type:</span>
            <span className={transaction.type === 'receive' ? 'text-green-500' : 'text-red-500'}>
              {transaction.type === 'receive' ? (
                <><ArrowDown className="inline mr-1" /> Received</>
              ) : (
                <><ArrowUp className="inline mr-1" /> Sent</>
              )}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Amount:</span>
            <span>{transaction.amount} {transaction.crypto}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Date:</span>
            <span>{new Date(transaction.date).toLocaleString()}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">From:</span>
            <span className="text-sm break-all">{transaction.from}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">To:</span>
            <span className="text-sm break-all">{transaction.to}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Network Fee:</span>
            <span>{transaction.networkFee} {transaction.crypto}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Confirmations:</span>
            <span>{transaction.confirmations}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Status:</span>
            <span>{transaction.status}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Block Height:</span>
            <span>{transaction.blockHeight}</span>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-center">
        <TransactionReceipt transaction={transaction} />
      </div>
    </div>
  )
}

