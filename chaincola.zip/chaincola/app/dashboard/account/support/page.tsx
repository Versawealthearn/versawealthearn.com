'use client'
import { ArrowLeft } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from 'next/link'
import { useRouter } from 'next/navigation'

export default function ContactSupportPage() {
  const router = useRouter()
  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="flex items-center mb-6">
        <Button variant="ghost" onClick={() => router.back()} className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-2xl font-bold">Contact Support</h1>
      </div>

      <Card className="bg-neutral-900 border-neutral-800">
        <CardHeader>
          <CardTitle className="text-white">Need Help?</CardTitle>
          <CardDescription>Our support team is here to assist you</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>For immediate assistance, you can reach out to us via WhatsApp:</p>
          <Link href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
            <Button className="w-full bg-green-600 hover:bg-green-700">
              Chat with us on WhatsApp
            </Button>
          </Link>
          <p>Our support hours are:</p>
          <ul className="list-disc list-inside">
            <li>Monday to Friday: 9am - 5pm</li>
            <li>Saturday: 10am - 2pm</li>
            <li>Sunday: Closed</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

