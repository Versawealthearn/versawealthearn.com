'use client'

import { useEffect } from 'react'
import { ArrowLeft } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from 'next/navigation'

export default function ChatPage() {
  const router = useRouter()
  useEffect(() => {
    // Load Tidio script
    const script = document.createElement('script')
    script.src = '//code.tidio.co/YOUR_TIDIO_KEY.js'
    script.async = true
    document.body.appendChild(script)

    return () => {
      // Clean up Tidio script when component unmounts
      document.body.removeChild(script)
    }
  }, [])

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="flex items-center mb-6">
        <Button variant="ghost" onClick={() => router.back()} className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-2xl font-bold">Chat with Us</h1>
      </div>

      <Card className="bg-neutral-900 border-neutral-800">
        <CardHeader>
          <CardTitle className="text-white">Live Chat Support</CardTitle>
          <CardDescription>Our team is ready to assist you</CardDescription>
        </CardHeader>
        <CardContent>
          <p>Click the chat icon in the bottom right corner to start a conversation with our support team.</p>
        </CardContent>
      </Card>
    </div>
  )
}

