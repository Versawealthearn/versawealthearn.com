'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Shield, Fingerprint, Lock, KeyRound, Moon, Bell, FileText, HeadphonesIcon, MessageSquare, HelpCircle, FileQuestion, Info, LogOut } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import Link from 'next/link'

export default function AccountPage() {
  const router = useRouter()
  const [biometricLogin, setBiometricLogin] = useState(false)
  const [biometricAuth, setBiometricAuth] = useState(true)
  const [darkMode, setDarkMode] = useState(false)
  const [emailNotifications, setEmailNotifications] = useState(true)

  const handleLogout = () => {
    // Implement logout logic here
    router.push('/login')
  }

  return (
    <div className="min-h-screen bg-black text-white p-4 pb-20">
      <h1 className="text-2xl font-bold mb-6">Account Settings</h1>

      {/* Security Section */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Security</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Fingerprint className="h-5 w-5 text-purple-500" />
              </div>
              <span>Biometric login</span>
            </div>
            <Switch 
              checked={biometricLogin}
              onCheckedChange={setBiometricLogin}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Shield className="h-5 w-5 text-purple-500" />
              </div>
              <span>Biometric authentication</span>
            </div>
            <Switch 
              checked={biometricAuth}
              onCheckedChange={setBiometricAuth}
            />
          </div>

          <Link href="/dashboard/account/change-pin" className="flex items-center justify-between py-2">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Lock className="h-5 w-5 text-purple-500" />
              </div>
              <span>Change transaction pin</span>
            </div>
            <div className="text-gray-400">→</div>
          </Link>

          <Link href="/dashboard/account/change-password" className="flex items-center justify-between py-2">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                <KeyRound className="h-5 w-5 text-purple-500" />
              </div>
              <span>Change login password</span>
            </div>
            <div className="text-gray-400">→</div>
          </Link>
        </div>
      </div>

      <Separator className="my-6 bg-neutral-800" />

      {/* Personalization Section */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Personalization</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Moon className="h-5 w-5 text-purple-500" />
              </div>
              <span>Dark mode</span>
            </div>
            <Switch 
              checked={darkMode}
              onCheckedChange={setDarkMode}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Bell className="h-5 w-5 text-purple-500" />
              </div>
              <span>Email login notifications</span>
            </div>
            <Switch 
              checked={emailNotifications}
              onCheckedChange={setEmailNotifications}
            />
          </div>
        </div>
      </div>

      <Separator className="my-6 bg-neutral-800" />

      {/* More Options Section */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">More options</h2>
        <Link href="/dashboard/account/statement" className="flex items-center justify-between py-2">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
              <FileText className="h-5 w-5 text-purple-500" />
            </div>
            <span>Generate statement of account</span>
          </div>
          <div className="text-gray-400">→</div>
        </Link>
      </div>

      <Separator className="my-6 bg-neutral-800" />

      {/* Help Section */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Help</h2>
        <div className="space-y-4">
          <Link href="/dashboard/account/support" className="flex items-center justify-between py-2">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                <HeadphonesIcon className="h-5 w-5 text-purple-500" />
              </div>
              <span>Contact support</span>
            </div>
            <div className="text-gray-400">→</div>
          </Link>

          <Link href="/dashboard/account/chat" className="flex items-center justify-between py-2">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                <MessageSquare className="h-5 w-5 text-purple-500" />
              </div>
              <span>Chat with us</span>
            </div>
            <div className="text-gray-400">→</div>
          </Link>
        </div>
      </div>

      <Separator className="my-6 bg-neutral-800" />

      {/* About Section */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">About</h2>
        <div className="space-y-4">
          <Link href="/dashboard/account/faq" className="flex items-center justify-between py-2">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                <FileQuestion className="h-5 w-5 text-purple-500" />
              </div>
              <span>Frequently asked questions</span>
            </div>
            <div className="text-gray-400">→</div>
          </Link>

          <Link href="/dashboard/account/terms" className="flex items-center justify-between py-2">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Info className="h-5 w-5 text-purple-500" />
              </div>
              <span>Terms & conditions</span>
            </div>
            <div className="text-gray-400">→</div>
          </Link>

          <Link href="/dashboard/account/privacy" className="flex items-center justify-between py-2">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Shield className="h-5 w-5 text-purple-500" />
              </div>
              <span>Privacy policy</span>
            </div>
            <div className="text-gray-400">→</div>
          </Link>
        </div>
      </div>

      <Button 
        variant="destructive" 
        className="w-full mt-6"
        onClick={handleLogout}
      >
        <LogOut className="h-5 w-5 mr-2" />
        Logout
      </Button>
    </div>
  )
}

