'use client'
import { ArrowLeft } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from 'next/navigation'

export default function TermsAndConditionsPage() {
  const router = useRouter()
  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="flex items-center mb-6">
        <Button variant="ghost" onClick={() => router.back()} className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-2xl font-bold">Terms & Conditions</h1>
      </div>

      <Card className="bg-neutral-900 border-neutral-800">
        <CardHeader>
          <CardTitle className="text-white">ChainCola Terms of Service</CardTitle>
          <CardDescription>Last updated: June 15, 2023</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Welcome to ChainCola. By using our services, you agree to be bound by the following terms and conditions:
          </p>
          <ol className="list-decimal list-inside space-y-2">
            <li>You must be at least 18 years old to use ChainCola.</li>
            <li>You are responsible for maintaining the security of your account and password.</li>
            <li>You agree to provide accurate and complete information when creating your account.</li>
            <li>ChainCola reserves the right to terminate or suspend your account at any time for any reason.</li>
            <li>You agree to use ChainCola in compliance with all applicable laws and regulations.</li>
          </ol>
          <p>
            For the full terms and conditions, please contact our support team.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

