'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function ChangeTransactionPINPage() {
  const router = useRouter()
  const [currentPIN, setCurrentPIN] = useState('')
  const [newPIN, setNewPIN] = useState('')
  const [confirmPIN, setConfirmPIN] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Implement PIN change logic here
    console.log('Changing PIN:', { currentPIN, newPIN, confirmPIN })
    // After successful change, navigate back to account page
    router.push('/dashboard/account')
  }

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="flex items-center mb-6">
        <Button variant="ghost" onClick={() => router.back()} className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-2xl font-bold">Change Transaction PIN</h1>
      </div>

      <Card className="bg-neutral-900 border-neutral-800">
        <CardHeader>
          <CardTitle className="text-white">Update Your PIN</CardTitle>
          <CardDescription>Enter your current PIN and choose a new one</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="currentPIN">Current PIN</Label>
              <Input
                id="currentPIN"
                type="password"
                value={currentPIN}
                onChange={(e) => setCurrentPIN(e.target.value)}
                className="bg-neutral-800 border-neutral-700 text-white"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="newPIN">New PIN</Label>
              <Input
                id="newPIN"
                type="password"
                value={newPIN}
                onChange={(e) => setNewPIN(e.target.value)}
                className="bg-neutral-800 border-neutral-700 text-white"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmPIN">Confirm New PIN</Label>
              <Input
                id="confirmPIN"
                type="password"
                value={confirmPIN}
                onChange={(e) => setConfirmPIN(e.target.value)}
                className="bg-neutral-800 border-neutral-700 text-white"
                required
              />
            </div>
            <Button type="submit" className="w-full">Update PIN</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

