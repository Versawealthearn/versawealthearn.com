'use client'
import { ArrowLeft } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from 'next/navigation'

export default function PrivacyPolicyPage() {
  const router = useRouter()
  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="flex items-center mb-6">
        <Button variant="ghost" onClick={() => router.back()} className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-2xl font-bold">Privacy Policy</h1>
      </div>

      <Card className="bg-neutral-900 border-neutral-800">
        <CardHeader>
          <CardTitle className="text-white">ChainCola Privacy Policy</CardTitle>
          <CardDescription>Last updated: June 15, 2023</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            At ChainCola, we are committed to protecting your privacy. This policy outlines how we collect, use, and protect your personal information:
          </p>
          <ol className="list-decimal list-inside space-y-2">
            <li>We collect personal information that you provide to us when creating an account or using our services.</li>
            <li>We use your information to provide and improve our services, and to communicate with you about your account.</li>
            <li>We do not sell or share your personal information with third parties for marketing purposes.</li>
            <li>We use industry-standard security measures to protect your personal information.</li>
            <li>You have the right to access, correct, or delete your personal information at any time.</li>
          </ol>
          <p>
            For the full privacy policy, please contact our support team.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

