'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Download, Mail } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"
import { addDays, format } from "date-fns"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function GenerateStatementPage() {
  const router = useRouter()
  const [date, setDate] = useState({
    from: new Date(),
    to: addDays(new Date(), 7),
  })
  const [statementType, setStatementType] = useState('all')
  const [email, setEmail] = useState('')
  const [isEmailDialogOpen, setIsEmailDialogOpen] = useState(false)
  const [isGenerating, setIsGenerating] = useState(false)

  const handleGenerateStatement = async () => {
    setIsGenerating(true)
    // Simulate statement generation
    await new Promise(resolve => setTimeout(resolve, 2000))
    setIsGenerating(false)

    // In a real application, you would generate the PDF here
    const pdfBlob = new Blob(['Dummy PDF content'], { type: 'application/pdf' })
    const pdfUrl = URL.createObjectURL(pdfBlob)
    const link = document.createElement('a')
    link.href = pdfUrl
    link.download = `statement_${format(date.from, 'yyyyMMdd')}_${format(date.to, 'yyyyMMdd')}.pdf`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(pdfUrl)
  }

  const handleSendEmail = async () => {
    // In a real application, you would send the email here
    console.log(`Sending statement to ${email}`)
    setIsEmailDialogOpen(false)
    // Simulate email sending
    await new Promise(resolve => setTimeout(resolve, 1000))
    alert('Statement sent to your email!')
  }

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="flex items-center mb-6">
        <Button variant="ghost" onClick={() => router.back()} className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-2xl font-bold">Generate Statement</h1>
      </div>

      <Card className="bg-neutral-900 border-neutral-800">
        <CardHeader>
          <CardTitle className="text-white">Account Statement</CardTitle>
          <CardDescription>Select a date range and transaction type</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="date-range">Date Range</Label>
            <DatePickerWithRange date={date} setDate={setDate} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="transaction-type">Transaction Type</Label>
            <Select value={statementType} onValueChange={setStatementType}>
              <SelectTrigger id="transaction-type" className="bg-neutral-800 border-neutral-700 text-white">
                <SelectValue placeholder="Select transaction type" />
              </SelectTrigger>
              <SelectContent className="bg-neutral-900 border-neutral-800 text-white">
                <SelectItem value="all">All Transactions</SelectItem>
                <SelectItem value="incoming">Incoming Only</SelectItem>
                <SelectItem value="outgoing">Outgoing Only</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex space-x-2">
            <Button 
              onClick={handleGenerateStatement} 
              className="flex-1"
              disabled={isGenerating}
            >
              <Download className="mr-2 h-4 w-4" />
              {isGenerating ? 'Generating...' : 'Download PDF'}
            </Button>
            <Dialog open={isEmailDialogOpen} onOpenChange={setIsEmailDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="flex-1">
                  <Mail className="mr-2 h-4 w-4" />
                  Email Statement
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-neutral-900 border-neutral-800 text-white">
                <DialogHeader>
                  <DialogTitle>Email Statement</DialogTitle>
                  <DialogDescription>
                    Enter your email address to receive the statement.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-neutral-800 border-neutral-700 text-white"
                    />
                  </div>
                  <Button onClick={handleSendEmail} className="w-full">
                    Send Statement
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

