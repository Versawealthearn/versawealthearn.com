'use client'

import { useState } from 'react'
import { ArrowLeft, QrCode, AlertCircle } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import Link from 'next/link'

export default function SendPage() {
  const [address, setAddress] = useState('')
  const [amount, setAmount] = useState('')
  const [currency, setCurrency] = useState('BTC')

  const handleSend = () => {
    // Implement send logic here
    console.log('Sending', amount, currency, 'to', address)
  }

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="flex items-center mb-6">
        <Link href="/dashboard" className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Link>
        <h1 className="text-2xl font-bold">Send</h1>
      </div>

      <div className="space-y-6">
        <div>
          <Label htmlFor="address">Recipient Address</Label>
          <div className="flex mt-2">
            <Input
              id="address"
              placeholder="Enter recipient's address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="flex-grow bg-neutral-900 border-neutral-800 text-white"
            />
            <Button variant="outline" className="ml-2 bg-neutral-900 border-neutral-800 text-white">
              <QrCode className="h-5 w-5" />
            </Button>
          </div>
        </div>

        <div>
          <Label htmlFor="amount">Amount</Label>
          <div className="flex mt-2">
            <Input
              id="amount"
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="flex-grow bg-neutral-900 border-neutral-800 text-white"
            />
            <Select value={currency} onValueChange={setCurrency}>
              <SelectTrigger className="w-[100px] ml-2 bg-neutral-900 border-neutral-800 text-white">
                <SelectValue placeholder="Currency" />
              </SelectTrigger>
              <SelectContent className="bg-neutral-900 border-neutral-800 text-white">
                <SelectItem value="BTC">BTC</SelectItem>
                <SelectItem value="ETH">ETH</SelectItem>
                <SelectItem value="USDC">USDC</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Alert variant="destructive" className="bg-red-900/50 border-red-900 text-red-300">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Warning</AlertTitle>
          <AlertDescription>
            Cryptocurrency transactions are irreversible. Please double-check the recipient's address and the amount before sending.
          </AlertDescription>
        </Alert>

        <Button onClick={handleSend} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
          Send
        </Button>
      </div>
    </div>
  )
}

