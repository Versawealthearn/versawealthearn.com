'use client'

import { useState } from 'react'
import { ArrowLeft, Plus, Search } from 'lucide-react'
import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Mock data for P2P offers
const mockOffers = [
  { id: 1, type: 'buy', crypto: 'BTC', price: 50000, amount: 0.5, user: 'Alice' },
  { id: 2, type: 'sell', crypto: 'ETH', price: 3000, amount: 2, user: 'Bob' },
  { id: 3, type: 'buy', crypto: 'USDC', price: 1, amount: 1000, user: 'Charlie' },
  { id: 4, type: 'sell', crypto: 'BTC', price: 51000, amount: 0.2, user: 'David' },
]

export default function MarketPage() {
  const [showNewOffer, setShowNewOffer] = useState(false)
  const [selectedCrypto, setSelectedCrypto] = useState<string | null>(null)

  const filteredOffers = selectedCrypto
    ? mockOffers.filter(offer => offer.crypto === selectedCrypto)
    : mockOffers

  return (
    <div className="min-h-screen bg-black text-white p-4 pb-20">
      <div className="flex items-center mb-6">
        <Link href="/dashboard" className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Link>
        <h1 className="text-2xl font-bold">P2P Market</h1>
      </div>

      <div className="flex justify-between items-center mb-6">
        <Select onValueChange={(value) => setSelectedCrypto(value)}>
          <SelectTrigger className="w-[180px] bg-neutral-900 border-neutral-800 text-white">
            <SelectValue placeholder="Filter by crypto" />
          </SelectTrigger>
          <SelectContent className="bg-neutral-900 border-neutral-800 text-white">
            <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
            <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
            <SelectItem value="USDC">USD Coin (USDC)</SelectItem>
          </SelectContent>
        </Select>

        <Dialog open={showNewOffer} onOpenChange={setShowNewOffer}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="mr-2 h-4 w-4" /> New Offer
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-neutral-900 border-neutral-800 text-white">
            <DialogHeader>
              <DialogTitle>Create New Offer</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div>
                <Label htmlFor="offer-type">Offer Type</Label>
                <Select>
                  <SelectTrigger id="offer-type" className="bg-neutral-800 border-neutral-700 text-white">
                    <SelectValue placeholder="Select offer type" />
                  </SelectTrigger>
                  <SelectContent className="bg-neutral-800 border-neutral-700 text-white">
                    <SelectItem value="buy">Buy</SelectItem>
                    <SelectItem value="sell">Sell</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="offer-crypto">Cryptocurrency</Label>
                <Select>
                  <SelectTrigger id="offer-crypto" className="bg-neutral-800 border-neutral-700 text-white">
                    <SelectValue placeholder="Select cryptocurrency" />
                  </SelectTrigger>
                  <SelectContent className="bg-neutral-800 border-neutral-700 text-white">
                    <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                    <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                    <SelectItem value="USDC">USD Coin (USDC)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="offer-amount">Amount</Label>
                <Input id="offer-amount" type="number" placeholder="0.00" className="bg-neutral-800 border-neutral-700 text-white" />
              </div>
              <div>
                <Label htmlFor="offer-price">Price per unit (USD)</Label>
                <Input id="offer-price" type="number" placeholder="0.00" className="bg-neutral-800 border-neutral-700 text-white" />
              </div>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Create Offer</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="buy" className="mb-6">
        <TabsList className="bg-neutral-900 border-neutral-800">
          <TabsTrigger value="buy" className="data-[state=active]:bg-blue-600">Buy</TabsTrigger>
          <TabsTrigger value="sell" className="data-[state=active]:bg-blue-600">Sell</TabsTrigger>
        </TabsList>
        <TabsContent value="buy">
          <div className="space-y-4">
            {filteredOffers.filter(offer => offer.type === 'buy').map(offer => (
              <Card key={offer.id} className="bg-neutral-900 border-neutral-800">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-semibold">{offer.crypto}</span>
                    <span className="text-sm text-gray-400">User: {offer.user}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Amount: {offer.amount} {offer.crypto}</span>
                    <span>Price: ${offer.price.toFixed(2)}</span>
                  </div>
                  <Button className="w-full mt-4 bg-green-600 hover:bg-green-700">Sell to this user</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="sell">
          <div className="space-y-4">
            {filteredOffers.filter(offer => offer.type === 'sell').map(offer => (
              <Card key={offer.id} className="bg-neutral-900 border-neutral-800">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-semibold">{offer.crypto}</span>
                    <span className="text-sm text-gray-400">User: {offer.user}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Amount: {offer.amount} {offer.crypto}</span>
                    <span>Price: ${offer.price.toFixed(2)}</span>
                  </div>
                  <Button className="w-full mt-4 bg-blue-600 hover:bg-blue-700">Buy from this user</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

