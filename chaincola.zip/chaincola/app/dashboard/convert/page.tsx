'use client'

import { useState } from 'react'
import { ArrowLeft, ArrowRightLeft } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from 'next/link'

export default function ConvertPage() {
  const [fromCurrency, setFromCurrency] = useState('BTC')
  const [toCurrency, setToCurrency] = useState('ETH')
  const [amount, setAmount] = useState('')
  const [estimatedAmount, setEstimatedAmount] = useState('')

  const handleConvert = () => {
    // In a real application, you would fetch the current exchange rate and calculate the estimated amount
    // For this example, we'll just set a mock value
    setEstimatedAmount((parseFloat(amount) * 15).toFixed(6))
  }

  const handleSwap = () => {
    const temp = fromCurrency
    setFromCurrency(toCurrency)
    setToCurrency(temp)
    setAmount('')
    setEstimatedAmount('')
  }

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="flex items-center mb-6">
        <Link href="/dashboard" className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Link>
        <h1 className="text-2xl font-bold">Convert</h1>
      </div>

      <div className="space-y-6">
        <div>
          <Label htmlFor="fromCurrency">From</Label>
          <div className="flex mt-2">
            <Input
              id="fromAmount"
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="flex-grow bg-neutral-900 border-neutral-800 text-white"
            />
            <Select value={fromCurrency} onValueChange={setFromCurrency}>
              <SelectTrigger className="w-[100px] ml-2 bg-neutral-900 border-neutral-800 text-white">
                <SelectValue placeholder="Currency" />
              </SelectTrigger>
              <SelectContent className="bg-neutral-900 border-neutral-800 text-white">
                <SelectItem value="BTC">BTC</SelectItem>
                <SelectItem value="ETH">ETH</SelectItem>
                <SelectItem value="USDC">USDC</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex justify-center">
          <Button onClick={handleSwap} variant="ghost" className="text-blue-500">
            <ArrowRightLeft className="h-6 w-6" />
          </Button>
        </div>

        <div>
          <Label htmlFor="toCurrency">To</Label>
          <div className="flex mt-2">
            <Input
              id="toAmount"
              type="number"
              placeholder="0.00"
              value={estimatedAmount}
              readOnly
              className="flex-grow bg-neutral-900 border-neutral-800 text-white"
            />
            <Select value={toCurrency} onValueChange={setToCurrency}>
              <SelectTrigger className="w-[100px] ml-2 bg-neutral-900 border-neutral-800 text-white">
                <SelectValue placeholder="Currency" />
              </SelectTrigger>
              <SelectContent className="bg-neutral-900 border-neutral-800 text-white">
                <SelectItem value="BTC">BTC</SelectItem>
                <SelectItem value="ETH">ETH</SelectItem>
                <SelectItem value="USDC">USDC</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="text-sm text-gray-400">
          1 {fromCurrency} = 15 {toCurrency}
        </div>

        <Button onClick={handleConvert} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
          Convert
        </Button>
      </div>
    </div>
  )
}

